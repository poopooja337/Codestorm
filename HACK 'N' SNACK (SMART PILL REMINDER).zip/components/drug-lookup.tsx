"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { AlertCircle, Loader, Search } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function DrugLookup() {
  const [searchTerm, setSearchTerm] = useState("")
  const [drugInfo, setDrugInfo] = useState(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleSearch = async (e) => {
    e.preventDefault()
    if (!searchTerm.trim()) {
      setError("Please enter a drug name")
      return
    }

    setIsLoading(true)
    setError("")
    setDrugInfo(null)

    try {
      // Using RxNorm API for drug information
      const response = await fetch(`https://rxnav.nlm.nih.gov/REST/drugs.json?name=${encodeURIComponent(searchTerm)}`)
      const data = await response.json()

      if (data.drugGroup && data.drugGroup.conceptGroup) {
        const conceptGroups = data.drugGroup.conceptGroup
        const drugConcepts = conceptGroups.find(
          (group) => group["@category"] === "DRUG_NAME" || group["@category"] === "INGREDIENT",
        )

        if (drugConcepts && drugConcepts.conceptProperties.length > 0) {
          const drug = drugConcepts.conceptProperties[0]

          // Get more detailed information
          const detailResponse = await fetch(`https://rxnav.nlm.nih.gov/REST/rxcui/${drug.rxcui}/properties.json`)
          const detailData = await detailResponse.json()

          setDrugInfo({
            name: drug.name,
            synonym: drug.synonym || "N/A",
            rxcui: drug.rxcui,
            tty: drug.tty,
            fullDetails: detailData.properties,
          })
        } else {
          setError("Drug not found. Please try a different name.")
        }
      } else {
        setError("Drug not found. Please try a different name.")
      }
    } catch (err) {
      setError("Failed to fetch drug information. Please try again.")
      console.error("Error fetching drug info:", err)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Drug Information Lookup</h2>
        <p className="text-gray-600 text-sm mt-1">Search for basic information about any medication</p>
      </div>

      {/* Search Form */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Search for a Drug</CardTitle>
          <CardDescription>Enter the name of a medication to get information about it</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="flex-1">
              <Input
                placeholder="e.g., Aspirin, Ibuprofen, Paracetamol..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="h-10"
              />
            </div>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader className="w-4 h-4 mr-2 animate-spin" />
                  Searching...
                </>
              ) : (
                <>
                  <Search className="w-4 h-4 mr-2" />
                  Search
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Error Message */}
      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Drug Information */}
      {drugInfo && (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-2xl text-blue-900">{drugInfo.name}</CardTitle>
            {drugInfo.synonym && (
              <CardDescription className="text-blue-700">Also known as: {drugInfo.synonym}</CardDescription>
            )}
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-lg">
                <p className="text-sm text-gray-600 font-medium">RxCUI</p>
                <p className="text-lg font-semibold text-gray-900">{drugInfo.rxcui}</p>
              </div>
              <div className="bg-white p-4 rounded-lg">
                <p className="text-sm text-gray-600 font-medium">Drug Type</p>
                <p className="text-lg font-semibold text-gray-900">{drugInfo.tty}</p>
              </div>
            </div>

            <Alert className="bg-blue-100 border-blue-300">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-900">
                For comprehensive drug information including interactions, side effects, and dosage guidelines, please
                consult with your healthcare provider or pharmacist.
              </AlertDescription>
            </Alert>

            <div className="bg-white p-4 rounded-lg border border-blue-200">
              <p className="text-sm text-gray-600 font-medium mb-2">Additional Information</p>
              <p className="text-sm text-gray-700">
                This information is sourced from the National Library of Medicine's RxNorm database. Always follow your
                doctor's or pharmacist's instructions for medication use.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Empty State */}
      {!drugInfo && !error && !isLoading && (
        <Card className="border-2 border-dashed">
          <CardContent className="pt-12 text-center">
            <Search className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">Search for a medication to get started</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
