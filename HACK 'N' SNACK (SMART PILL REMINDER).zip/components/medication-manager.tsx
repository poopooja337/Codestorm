"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Trash2, Edit2, Plus } from "lucide-react"

export default function MedicationManager({ medications, onAddMedication, onUpdateMedication, onDeleteMedication }) {
  const [isOpen, setIsOpen] = useState(false)
  const [editingId, setEditingId] = useState(null)
  const [formData, setFormData] = useState({
    name: "",
    dosage: "",
    purpose: "",
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!formData.name || !formData.dosage) {
      alert("Please fill in all fields")
      return
    }

    if (editingId) {
      onUpdateMedication(editingId, formData)
      setEditingId(null)
    } else {
      onAddMedication(formData)
    }

    setFormData({ name: "", dosage: "", purpose: "" })
    setIsOpen(false)
  }

  const handleEdit = (med) => {
    setFormData({
      name: med.name,
      dosage: med.dosage,
      purpose: med.purpose || "",
    })
    setEditingId(med.id)
    setIsOpen(true)
  }

  const handleClose = () => {
    setIsOpen(false)
    setEditingId(null)
    setFormData({ name: "", dosage: "", purpose: "" })
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">My Medicines</h2>
          <p className="text-gray-600 text-sm mt-1">Manage your medications here</p>
        </div>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Medicine
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingId ? "Edit Medicine" : "Add New Medicine"}</DialogTitle>
              <DialogDescription>Enter your medicine details below</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Medicine Name *</label>
                <Input
                  placeholder="e.g., Aspirin"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Dosage *</label>
                <Input
                  placeholder="e.g., 500mg"
                  value={formData.dosage}
                  onChange={(e) => setFormData({ ...formData, dosage: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Purpose (optional)</label>
                <Input
                  placeholder="e.g., Headache relief"
                  value={formData.purpose}
                  onChange={(e) => setFormData({ ...formData, purpose: e.target.value })}
                />
              </div>
              <div className="flex gap-2 justify-end pt-4">
                <Button type="button" variant="outline" onClick={handleClose}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  {editingId ? "Update" : "Add"} Medicine
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {medications.length === 0 ? (
        <Card className="border-2 border-dashed">
          <CardContent className="pt-12 text-center">
            <p className="text-gray-500">No medicines added yet. Click "Add Medicine" to get started!</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {medications.map((med) => (
            <Card key={med.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg">{med.name}</CardTitle>
                <CardDescription>{med.dosage}</CardDescription>
              </CardHeader>
              <CardContent>
                {med.purpose && <p className="text-sm text-gray-600 mb-4">{med.purpose}</p>}
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => handleEdit(med)} className="flex-1">
                    <Edit2 className="w-4 h-4 mr-1" />
                    Edit
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => {
                      if (confirm("Delete this medicine?")) {
                        onDeleteMedication(med.id)
                      }
                    }}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
