"use client"

import { useState, useMemo } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

export default function MedicineHistory({ reminders, medications }) {
  const [timeFilter, setTimeFilter] = useState("today")
  const [selectedMedicine, setSelectedMedicine] = useState(null)

  const filteredReminders = useMemo(() => {
    const now = new Date()
    let startDate = new Date()

    switch (timeFilter) {
      case "today":
        startDate.setHours(0, 0, 0, 0)
        break
      case "week":
        startDate.setDate(now.getDate() - 7)
        break
      case "month":
        startDate.setMonth(now.getMonth() - 1)
        break
      case "all":
        startDate = new Date(2000, 0, 1)
        break
    }

    return reminders.filter((r) => {
      if (!r.lastTaken) return false
      return new Date(r.lastTaken) >= startDate
    })
  }, [reminders, timeFilter])

  const medicineStats = useMemo(() => {
    const stats = {}
    filteredReminders.forEach((r) => {
      const med = medications.find((m) => m.id === r.medicationId)
      if (med) {
        stats[med.name] = (stats[med.name] || 0) + 1
      }
    })
    return Object.entries(stats).map(([name, count]) => ({ name, count }))
  }, [filteredReminders, medications])

  const totalMedicines = filteredReminders.length
  const uniqueMedicines = new Set(filteredReminders.map((r) => r.medicationId)).size
  const mostFrequent = medicineStats.length > 0 ? medicineStats.reduce((a, b) => (a.count > b.count ? a : b)) : null

  const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6"]

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-4">
          <p className="text-sm text-gray-600 mb-1">Total Taken</p>
          <p className="text-3xl font-bold text-blue-600">{totalMedicines}</p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-gray-600 mb-1">Different Medicines</p>
          <p className="text-3xl font-bold text-green-600">{uniqueMedicines}</p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-gray-600 mb-1">Most Frequent</p>
          <p className="text-lg font-bold text-purple-600">{mostFrequent?.name || "N/A"}</p>
        </Card>
      </div>

      <div className="flex gap-2">
        {["today", "week", "month", "all"].map((filter) => (
          <Button
            key={filter}
            onClick={() => setTimeFilter(filter)}
            variant={timeFilter === filter ? "default" : "outline"}
            className={timeFilter === filter ? "bg-blue-600" : ""}
          >
            {filter.charAt(0).toUpperCase() + filter.slice(1)}
          </Button>
        ))}
      </div>

      {medicineStats.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="p-4">
            <h3 className="font-semibold mb-4">Medicine Count</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={medicineStats}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </Card>

          <Card className="p-4">
            <h3 className="font-semibold mb-4">Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={medicineStats}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={{ key: "name" }}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="count"
                >
                  {medicineStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </Card>
        </div>
      )}

      {filteredReminders.length > 0 && (
        <Card className="p-4">
          <h3 className="font-semibold mb-4">Recent Intake Log</h3>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {filteredReminders
              .slice()
              .reverse()
              .map((reminder) => {
                const med = medications.find((m) => m.id === reminder.medicationId)
                return (
                  <div
                    key={reminder.id}
                    onClick={() => setSelectedMedicine(med?.id === selectedMedicine ? null : med?.id)}
                    className="p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-gray-900">{med?.name}</p>
                        <p className="text-sm text-gray-600">{med?.dosage}</p>
                      </div>
                      <p className="text-sm text-gray-500">{new Date(reminder.lastTaken).toLocaleString()}</p>
                    </div>
                  </div>
                )
              })}
          </div>
        </Card>
      )}

      {filteredReminders.length === 0 && (
        <Card className="p-8 text-center">
          <p className="text-gray-500">No medication intake records for the selected period</p>
        </Card>
      )}
    </div>
  )
}
