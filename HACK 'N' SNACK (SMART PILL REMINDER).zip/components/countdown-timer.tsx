"use client"

import { useState, useEffect } from "react"
import { Clock } from "lucide-react"

export default function CountdownTimer({ reminders, medications }) {
  const [nextReminder, setNextReminder] = useState(null)
  const [timeLeft, setTimeLeft] = useState("")

  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date()
      const today = now.toDateString()

      let closestReminder = null
      let closestTime = null

      reminders.forEach((reminder) => {
        const [hours, minutes] = reminder.time.split(":").map(Number)
        const reminderDate = new Date()
        reminderDate.setHours(hours, minutes, 0, 0)

        if (reminderDate > now) {
          if (!closestTime || reminderDate < closestTime) {
            closestReminder = reminder
            closestTime = reminderDate
          }
        }
      })

      if (closestReminder && closestTime) {
        setNextReminder(closestReminder)
        const diff = closestTime - now
        const hours = Math.floor(diff / (1000 * 60 * 60))
        const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
        const secs = Math.floor((diff % (1000 * 60)) / 1000)
        setTimeLeft(`${hours}h ${mins}m ${secs}s`)
      } else {
        setNextReminder(null)
        setTimeLeft("")
      }
    }

    updateCountdown()
    const interval = setInterval(updateCountdown, 1000)
    return () => clearInterval(interval)
  }, [reminders])

  if (!nextReminder) return null

  const medication = medications.find((m) => m.id === nextReminder.medicationId)

  return (
    <div className="mb-6 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg p-4 shadow-lg">
      <div className="flex items-center gap-3">
        <Clock className="w-5 h-5" />
        <div className="flex-1">
          <p className="text-sm opacity-90">Next Medication</p>
          <p className="font-semibold">
            {medication?.name} - {nextReminder.time}
          </p>
          <p className="text-sm opacity-75">Time remaining: {timeLeft}</p>
        </div>
      </div>
    </div>
  )
}
