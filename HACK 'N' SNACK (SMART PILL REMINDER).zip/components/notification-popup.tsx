"use client"

import { useState, useEffect } from "react"
import { X, Volume2 } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function NotificationPopup({ reminders, medications, onMarkTaken }) {
  const [notificationReminder, setNotificationReminder] = useState(null)
  const [medicineTakenToday, setMedicineTakenToday] = useState(0)
  const [audioRef, setAudioRef] = useState(null)

  useEffect(() => {
    const audio = new Audio(
      "data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAAB9AAACABAAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj==",
    )
    setAudioRef(audio)
  }, [])

  useEffect(() => {
    const checkReminders = () => {
      const now = new Date()
      const currentTime =
        now.getHours().toString().padStart(2, "0") + ":" + now.getMinutes().toString().padStart(2, "0")
      const today = now.toDateString()

      const todaysTaken = reminders.filter((r) => {
        if (!r.lastTaken) return false
        const takenDate = new Date(r.lastTaken).toDateString()
        return takenDate === today
      }).length

      setMedicineTakenToday(todaysTaken)

      const dueReminder = reminders.find((r) => r.time === currentTime && !r.notified)
      if (dueReminder) {
        setNotificationReminder(dueReminder)
        if (audioRef) audioRef.play()
      }
    }

    checkReminders()
    const interval = setInterval(checkReminders, 10000)
    return () => clearInterval(interval)
  }, [reminders, audioRef])

  if (!notificationReminder) return null

  const medication = medications.find((m) => m.id === notificationReminder.medicationId)

  const handleMarkTaken = () => {
    onMarkTaken(notificationReminder.id)
    setNotificationReminder(null)
  }

  const handleDismiss = () => {
    setNotificationReminder(null)
  }

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
      <div className="bg-white rounded-xl shadow-2xl p-8 max-w-md w-full animate-in zoom-in">
        <button onClick={handleDismiss} className="float-right text-gray-400 hover:text-gray-600">
          <X className="w-6 h-6" />
        </button>

        <div className="text-center mb-6">
          <div className="inline-block bg-blue-100 p-4 rounded-full mb-4">
            <Volume2 className="w-8 h-8 text-blue-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Time for Medicine!</h2>
        </div>

        <div className="bg-gray-50 rounded-lg p-4 mb-6 space-y-2">
          <div>
            <p className="text-sm text-gray-600">Medicine</p>
            <p className="text-lg font-semibold text-gray-900">{medication?.name}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Dosage</p>
            <p className="text-lg font-semibold text-gray-900">{medication?.dosage}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Scheduled Time</p>
            <p className="text-lg font-semibold text-gray-900">{notificationReminder.time}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Medicines Taken Today</p>
            <p className="text-lg font-semibold text-green-600">{medicineTakenToday}</p>
          </div>
        </div>

        <div className="flex gap-3">
          <Button onClick={handleMarkTaken} className="flex-1 bg-green-600 hover:bg-green-700 text-white">
            Mark as Taken
          </Button>
          <Button onClick={handleDismiss} variant="outline" className="flex-1 bg-transparent">
            Dismiss
          </Button>
        </div>
      </div>
    </div>
  )
}
