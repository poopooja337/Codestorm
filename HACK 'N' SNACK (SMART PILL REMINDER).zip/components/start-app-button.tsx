"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Play, Square } from "lucide-react"
import { NotificationService } from "@/lib/notification-service"

export default function StartAppButton({ onStart, onStop }) {
  const [isRunning, setIsRunning] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleStartApp = async () => {
    setIsLoading(true)

    // Request notification permission
    const granted = await NotificationService.requestPermission()

    if (granted) {
      setIsRunning(true)
      NotificationService.sendNotification("Medi-Friend Started!", {
        body: "Your medication reminder system is now active",
      })
      onStart && onStart()
    }

    setIsLoading(false)
  }

  const handleStopApp = () => {
    setIsRunning(false)
    onStop && onStop()
  }

  return (
    <div className="flex items-center gap-2">
      {isRunning && (
        <div className="flex items-center gap-1 text-xs text-green-600 bg-green-50 px-2 py-1 rounded">
          <span className="inline-block w-2 h-2 bg-green-600 rounded-full animate-pulse"></span>
          System Active
        </div>
      )}
      <Button
        onClick={isRunning ? handleStopApp : handleStartApp}
        disabled={isLoading}
        variant={isRunning ? "destructive" : "default"}
        size="sm"
        className={isRunning ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"}
      >
        {isRunning ? (
          <>
            <Square className="w-4 h-4 mr-2" />
            Stop App
          </>
        ) : (
          <>
            <Play className="w-4 h-4 mr-2" />
            Start App
          </>
        )}
      </Button>
    </div>
  )
}
