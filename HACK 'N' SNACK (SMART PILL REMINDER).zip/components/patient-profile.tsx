"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { User } from "lucide-react"

export default function PatientProfile() {
  const [isOpen, setIsOpen] = useState(false)
  const [name, setName] = useState("")
  const [age, setAge] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const savedName = localStorage.getItem("patientName")
    const savedAge = localStorage.getItem("patientAge")

    if (savedName) setName(savedName)
    if (savedAge) setAge(savedAge)

    setIsLoading(false)
  }, [])

  const handleSave = () => {
    localStorage.setItem("patientName", name)
    localStorage.setItem("patientAge", age)
    setIsOpen(false)
  }

  if (isLoading) {
    return null
  }

  return (
    <div className="relative">
      <Button onClick={() => setIsOpen(!isOpen)} variant="outline" size="sm" className="flex items-center gap-2">
        <User className="w-4 h-4" />
        {name ? `${name}, ${age}` : "Profile"}
      </Button>

      {isOpen && (
        <div className="absolute top-12 right-0 bg-white border border-gray-200 rounded-lg shadow-lg p-4 w-64 z-50">
          <h3 className="font-semibold text-gray-900 mb-4">Patient Profile</h3>

          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your name"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Age</label>
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                placeholder="Enter your age"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="flex gap-2 mt-4">
            <Button onClick={handleSave} size="sm" className="flex-1 bg-blue-600 hover:bg-blue-700">
              Save
            </Button>
            <Button onClick={() => setIsOpen(false)} variant="outline" size="sm" className="flex-1">
              Cancel
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
