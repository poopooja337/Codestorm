"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CheckCircle2, Clock, Plus } from "lucide-react"
import { NotificationService } from "@/lib/notification-service"

export default function ReminderTracker({ reminders, medications, onAddReminder, onMarkTaken }) {
  const [isOpen, setIsOpen] = useState(false)
  const [formData, setFormData] = useState({
    medicationId: "",
    time: "",
    frequency: "daily",
  })

  useEffect(() => {
    if (!NotificationService.isEnabled()) return

    const checkAndNotify = () => {
      const now = new Date()
      const currentTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`

      reminders.forEach((reminder) => {
        const isTakenToday =
          reminder.status === "taken" && new Date(reminder.lastTaken).toDateString() === now.toDateString()

        if (reminder.time === currentTime && !isTakenToday) {
          const medName = getMedicationName(reminder.medicationId)
          const med = medications.find((m) => m.id === reminder.medicationId)
          const dosage = med?.dosage || "as prescribed"

          NotificationService.sendMedicationReminder(medName, dosage, reminder.time)
        }
      })
    }

    // Check every minute
    const interval = setInterval(checkAndNotify, 60000)

    // Also check immediately on mount
    checkAndNotify()

    return () => clearInterval(interval)
  }, [reminders, medications])

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!formData.medicationId || !formData.time) {
      alert("Please fill in all fields")
      return
    }

    onAddReminder(formData)
    setFormData({ medicationId: "", time: "", frequency: "daily" })
    setIsOpen(false)
  }

  const getMedicationName = (medId) => {
    return medications.find((m) => m.id === medId)?.name || "Unknown Medicine"
  }

  const getUpcomingReminders = () => {
    return reminders.filter(
      (r) => r.status !== "taken" || new Date(r.lastTaken).toDateString() !== new Date().toDateString(),
    )
  }

  const getTakenToday = () => {
    return reminders.filter(
      (r) => r.status === "taken" && new Date(r.lastTaken).toDateString() === new Date().toDateString(),
    )
  }

  const upcomingReminders = getUpcomingReminders()
  const takenToday = getTakenToday()

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Medication Reminders</h2>
          <p className="text-gray-600 text-sm mt-1">Track and manage your daily reminders</p>
        </div>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Reminder
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Reminder</DialogTitle>
              <DialogDescription>Set up a reminder for one of your medicines</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Select Medicine *</label>
                <Select
                  value={formData.medicationId}
                  onValueChange={(value) => setFormData({ ...formData, medicationId: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a medicine" />
                  </SelectTrigger>
                  <SelectContent>
                    {medications.map((med) => (
                      <SelectItem key={med.id} value={med.id}>
                        {med.name} - {med.dosage}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Reminder Time *</label>
                <Input
                  type="time"
                  value={formData.time}
                  onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Frequency</label>
                <Select
                  value={formData.frequency}
                  onValueChange={(value) => setFormData({ ...formData, frequency: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="twice-daily">Twice Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="as-needed">As Needed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-2 justify-end pt-4">
                <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  Create Reminder
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Stats */}
      <div className="grid gap-4 md:grid-cols-2 mb-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Taken Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{takenToday.length}</div>
            <p className="text-xs text-gray-500 mt-1">medications completed</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Upcoming</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{upcomingReminders.length}</div>
            <p className="text-xs text-gray-500 mt-1">pending reminders</p>
          </CardContent>
        </Card>
      </div>

      {/* Reminders List */}
      {reminders.length === 0 ? (
        <Card className="border-2 border-dashed">
          <CardContent className="pt-12 text-center">
            <p className="text-gray-500">No reminders set yet. Create one to get started!</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Pending Reminders</h3>
            {upcomingReminders.length === 0 ? (
              <Card className="bg-green-50 border-green-200">
                <CardContent className="pt-6 text-center">
                  <p className="text-green-700">All medications taken today!</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-3">
                {upcomingReminders.map((reminder) => (
                  <Card key={reminder.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">{getMedicationName(reminder.medicationId)}</h4>
                          <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                            <span className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              {reminder.time}
                            </span>
                            <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">
                              {reminder.frequency}
                            </span>
                          </div>
                        </div>
                        <Button
                          onClick={() => onMarkTaken(reminder.id)}
                          className="bg-green-600 hover:bg-green-700"
                          size="sm"
                        >
                          <CheckCircle2 className="w-4 h-4 mr-1" />
                          Mark Taken
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {takenToday.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Completed Today</h3>
              <div className="grid gap-3">
                {takenToday.map((reminder) => (
                  <Card key={reminder.id} className="bg-green-50 border-green-200">
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <CheckCircle2 className="w-5 h-5 text-green-600" />
                            <h4 className="font-semibold text-gray-900">{getMedicationName(reminder.medicationId)}</h4>
                          </div>
                          <p className="text-sm text-green-700 mt-1">
                            Taken at{" "}
                            {new Date(reminder.lastTaken).toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
