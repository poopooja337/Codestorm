"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Bell, BellOff } from "lucide-react"
import { NotificationService } from "@/lib/notification-service"

export default function NotificationToggle() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    // Check if notifications are already enabled
    const enabled = NotificationService.isEnabled()
    setNotificationsEnabled(enabled)
  }, [])

  const handleToggleNotifications = async () => {
    setIsLoading(true)
    const granted = await NotificationService.requestPermission()
    if (granted) {
      setNotificationsEnabled(true)
      NotificationService.sendNotification("Notifications Enabled!", {
        body: "You'll now receive medication reminders",
      })
    } else {
      setNotificationsEnabled(false)
    }
    setIsLoading(false)
  }

  return (
    <Button
      onClick={handleToggleNotifications}
      disabled={isLoading}
      variant={notificationsEnabled ? "default" : "outline"}
      size="sm"
      className={notificationsEnabled ? "bg-blue-600 hover:bg-blue-700" : ""}
    >
      {notificationsEnabled ? (
        <>
          <Bell className="w-4 h-4 mr-2" />
          Notifications On
        </>
      ) : (
        <>
          <BellOff className="w-4 h-4 mr-2" />
          Notifications Off
        </>
      )}
    </Button>
  )
}
