"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import MedicationManager from "@/components/medication-manager"
import ReminderTracker from "@/components/reminder-tracker"
import NotificationToggle from "@/components/notification-toggle"
import StartAppButton from "@/components/start-app-button"
import PatientProfile from "@/components/patient-profile"
import CountdownTimer from "@/components/countdown-timer"
import NotificationPopup from "@/components/notification-popup"
import MedicineHistory from "@/components/medicine-history"

export default function Home() {
  const [medications, setMedications] = useState([])
  const [reminders, setReminders] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [isAppRunning, setIsAppRunning] = useState(false)

  useEffect(() => {
    const savedMeds = localStorage.getItem("medications")
    const savedReminders = localStorage.getItem("reminders")

    if (savedMeds) setMedications(JSON.parse(savedMeds))
    if (savedReminders) setReminders(JSON.parse(savedReminders))

    setIsLoading(false)
  }, [])

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem("medications", JSON.stringify(medications))
    }
  }, [medications, isLoading])

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem("reminders", JSON.stringify(reminders))
    }
  }, [reminders, isLoading])

  const addMedication = (medication) => {
    const newMed = { ...medication, id: Date.now().toString() }
    setMedications([...medications, newMed])
  }

  const updateMedication = (id, updated) => {
    setMedications(medications.map((med) => (med.id === id ? { ...med, ...updated } : med)))
  }

  const deleteMedication = (id) => {
    setMedications(medications.filter((med) => med.id !== id))
    setReminders(reminders.filter((rem) => rem.medicationId !== id))
  }

  const addReminder = (reminder) => {
    const newReminder = { ...reminder, id: Date.now().toString() }
    setReminders([...reminders, newReminder])
  }

  const markReminderTaken = (id) => {
    setReminders(
      reminders.map((rem) => (rem.id === id ? { ...rem, lastTaken: new Date().toISOString(), status: "taken" } : rem)),
    )
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mb-4"></div>
          <p className="text-gray-600">Loading your medications...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-6 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">💊 Medi-Friend</h1>
            <p className="text-gray-600 text-sm mt-1">Your trusted medication reminder companion</p>
          </div>
          <div className="flex items-center gap-4">
            <StartAppButton onStart={() => setIsAppRunning(true)} onStop={() => setIsAppRunning(false)} />
            <NotificationToggle />
            <PatientProfile />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {isAppRunning && <CountdownTimer reminders={reminders} medications={medications} />}

        <Tabs defaultValue="reminders" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="reminders">My Reminders</TabsTrigger>
            <TabsTrigger value="medications">My Medicines</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>

          <TabsContent value="reminders" className="space-y-4">
            <ReminderTracker
              reminders={reminders}
              medications={medications}
              onAddReminder={addReminder}
              onMarkTaken={markReminderTaken}
              isAppRunning={isAppRunning}
            />
          </TabsContent>

          <TabsContent value="medications" className="space-y-4">
            <MedicationManager
              medications={medications}
              onAddMedication={addMedication}
              onUpdateMedication={updateMedication}
              onDeleteMedication={deleteMedication}
            />
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            <MedicineHistory reminders={reminders} medications={medications} />
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="mt-16 bg-white border-t border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-6 text-center text-sm text-gray-600">
          <p>Medi-Friend - Your Health, Our Priority | Always consult with your healthcare provider</p>
        </div>
      </footer>

      {isAppRunning && (
        <NotificationPopup reminders={reminders} medications={medications} onMarkTaken={markReminderTaken} />
      )}
    </div>
  )
}
