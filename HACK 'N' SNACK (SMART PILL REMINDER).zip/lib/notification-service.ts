// Notification Service for browser notifications
export const NotificationService = {
  // Request permission from user
  requestPermission: async () => {
    if (!("Notification" in window)) {
      console.log("This browser does not support notifications")
      return false
    }

    if (Notification.permission === "granted") {
      return true
    }

    if (Notification.permission !== "denied") {
      const permission = await Notification.requestPermission()
      return permission === "granted"
    }

    return false
  },

  // Send a notification
  sendNotification: (title: string, options?: NotificationOptions) => {
    if (Notification.permission === "granted") {
      new Notification(title, {
        icon: "/pill-icon.png",
        tag: "medication-reminder",
        requireInteraction: true,
        ...options,
      })
    }
  },

  // Send medication reminder notification
  sendMedicationReminder: (medicationName: string, dosage: string, time: string) => {
    NotificationService.sendNotification(`🔔 Time to take ${medicationName}`, {
      body: `Dosage: ${dosage} at ${time}`,
      badge: "/pill-icon.png",
    })
  },

  // Check if notifications are supported and enabled
  isEnabled: () => {
    return "Notification" in window && Notification.permission === "granted"
  },
}
